<?php 
require_once 'verif.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="log.css">
    <title>page visiteur</title>
</head>
<body>
    <header>
    <h2> <?php echo $login; ?></h2>
<div id='conteneur'>
<a href="#">  <div class='at'>accueil</div></a>

    <a href="#">  <div class='at'>profil</div></a>
    <a href="#"> <div class='at'>photo</div></a>
    <a href="#"> <div class='at'>classe</div></a>
    <a href="sd.php"> <div class='at'>deconnection</div></a>
    </div>
</header>

<section>
<main>
    <div class="vi"><video src="Dip Doundu Guiss - NLMD  (Official Video).mp4" controls>nlmd</video></div>
    <div class="vid"></div>
</main>
    <aside><nav><ul type='none'>
        <li><a href="formulaireAge.php">formulaire</a></li> <hr>
        <li><a href="projetniangetwane.php">tableu</a></li><hr>
        <li><a href="Calculatrice.php">calculatrice</a></li> <hr>
        <li><a href="#"></a></li><hr>


    </ul></nav></aside>
    </section>
</body>
</html>