<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Age</title>
</head>
<body>
<form action="affichage.php" methode="post">
	<table align="center" border="1">
	  <tr><td>Votre age<input type="text" name="age"/></td></tr>
	  <tr><td>Votre sexe<input type="number" name="age"/></td></tr>
	  <tr><td><input type="submit" name="valider" value="Valider"></td></tr>
    </table>

</form>	
</body>
</html>



