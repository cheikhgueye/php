<?php

    session_start();
    $login = isset($_POST['nom']) ? $_POST['nom'] : '';
    $pass = isset($_POST['pass']) ? $_POST['pass'] : '';
    $pro = isset($_POST['pro']) ? $_POST['pro'] : '';
    extract($_POST);

    $t = array($login, $pass, $pro);

           $fichier = file('fichie.txt');
             $tab = array();
           for ($i = 0; $i < count($fichier); ++$i) {
               $x = explode(';', $fichier[$i]);
               array_push($tab, $x);
           }
           $c = 0;
          for ($i = 0; $i < count($tab); ++$i) {
              for ($j = 0; $j < 3; ++$j) {
                  if ($tab[$i][$j] == $t[$j]) {
                      ++$c;
                  }
              }
          }
     if ($c < 2) {
         header('location: genererpass.php');
     } else {
         if ($pro == 'admin') {
             $_SESSION['nom'] = $login;
             $_SESSION['passs'] = $pass;
             $_SESSION['logged'] = true;
             header('location: ma_session1.php');
         } elseif ($pro == 'user') {
             $_SESSION['nom'] = $login;
             $_SESSION['pass'] = $pass;
             $_SESSION['logged'] = true;
             header('location: ma_session2.php');
         }
     }
