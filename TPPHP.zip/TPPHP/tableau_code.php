<<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <?php
    $tab=array(array($_nom=Peush,$_nom=DasaBoss,$_nom=Pipo),array($_age=25,$_age=23,$_age=30)...)
    echo"











?>
    
    </body>
</html>